from django.apps import AppConfig


class IblogConfig(AppConfig):
    name = 'iblog'
