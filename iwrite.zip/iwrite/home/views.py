from django.shortcuts import render, HttpResponse, redirect
from home.models import Contact
from iblog.models import Post
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout


# Create your views here.

# Render to html pages
def home(request):
    allPost = Post.objects.all()
    context = {'allPost':allPost}
    return render(request, 'home/home.html', context)
    # return HttpResponse('This is home page')

def contact(request):
    # messages.error(request, 'Welcome on Contact Page.')
    if request.method == "POST":
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        content = request.POST['content']

        if len(name)<2 or len(email)<2 or len(phone)<10 or len(content)<4:
            messages.error(request, 'Please fill the form correctly.')

        else:
            contact = Contact(name=name, email=email, phone=phone, content=content)
            contact.save()

            messages.success(request, 'Your message has been sent successfully.')

    return render(request, 'home/contact.html')
    # return HttpResponse('This is contact page')

def about(request):
    return render(request, 'home/about.html')
    # return HttpResponse('This is about page')

def search(request):
    query = request.GET['query']
    if len(query) > 50 or len(query) < 1:
        allPost = Post.objects.none()
        messages.warning(request, 'Please enter correct query.')

    else:
        allPostTitle = Post.objects.filter(title__icontains=query)
        allPostContent = Post.objects.filter(content__icontains=query)
        allPost = allPostTitle.union(allPostContent)

    params = {'allPost':allPost, 'query':query}
    return render(request, 'home/search.html', params)
    # return HttpResponse('this is search')

# APIs to handel user signUp, logIn, logOut
def handelSignup(request):
    if request.method == 'POST':

        #Get the post parameters
        username = request.POST['username']
        fname = request.POST['fname']
        lname = request.POST['lname']
        email = request.POST['email']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']

        #check for inputs
        if len(username) < 4:
            messages.error(request, 'Username is too short.')
            return redirect('home')

        if not username.isalnum():
            messages.error(request, 'Username should contain letters and number.')
            return redirect('home')

        if pass1 != pass2:
            messages.error(request, 'Both passwords are different.')
            return redirect('home')

        #create the user
        myuser = User.objects.create_user(username, email, pass1)
        myuser.first_name = fname
        myuser.last_name = lname
        myuser.save()
        messages.success(request, 'Your account has been created successfully.')
        return redirect('home')
    else:
        return HttpResponse("404 - Not found")

def handelLogin(request):
    if request.method == 'POST':

        # Get user credetials
        loginusername = request.POST['loginusername']
        loginpassword = request.POST['loginpassword']

        user = authenticate(username = loginusername, password = loginpassword)

        if user is not None:
            login(request, user)
            messages.success(request, 'You have logged in Successfully')
            return redirect('home')

        else:
            messages.error(request, 'Invalid credential!!! Please try again.')
            return redirect('home')

    return HttpResponse('404 - Not found')

def handelLogout(request):

    logout(request)
    messages.success(request, 'Log out successfully')
    return redirect('home')
    

    